export class Service {
  run() { return true; }
}
