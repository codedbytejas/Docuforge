def main():
    print('main')
